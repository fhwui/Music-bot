There is copy right on this the Name "Jesse S." Is not to be removed off of this bot, 
I am giving this bot to "Justin W. | Justin's Solutions"


To set the bot up go to the config folder then click in bot.js
put in your token where it say's TOKEN in Line 11
put in yout Prefix in line 12
Then put your Status that you want in Line 13
And enjoy!

You do not have Reseller/Giveaway permissions from the Developer (Jesse S.)
This is just a bot JUST for you and your server's direct them to CADHost to recive a bot like this, Here is a invite link for CADHost to send to them https://discord.gg/Rn3RGknCb3 